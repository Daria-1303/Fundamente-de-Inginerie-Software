public interface Visitor {
    public void visitNumar(Numar n);
    public void visitSuma(Suma s);
    public void visitInmultire(Inmultire i);
}