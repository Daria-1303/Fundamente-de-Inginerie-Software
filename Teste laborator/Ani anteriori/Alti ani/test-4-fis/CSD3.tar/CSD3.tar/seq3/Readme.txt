Starting from the line marked with a *, draw the sequence diagram that includes all the interactions between the objects.

